import { Injectable } from '@angular/core';
import { Quiz } from './quiz.model';

@Injectable({
  providedIn: 'root'
})
export class QuizService {

  quizzes: Quiz[] = [
  {
    question:'You are setting up for virtualization on a personal workstation\. What is the minimum amount of Random Access Memory recommended for the host operating system\?',
    answer:[
      {option:'4 or 5 GB', correct: false},
      {option:'1 or 2 MB', correct: false},
      {option:'32 or 64 GB', correct: false},
      {option:'1 or 2 GB', correct: true}
    ]
  },
  {
    question:'Identify the industry\-standard format for storing virtual machine files\.',
    answer:[
      {option:'Comma-separated value format \(CSVF\)', correct: false},
      {option:'Open Format for Virtualization \(OFV\)', correct: false},
      {option:'Open Virtualization Format \(OVF\)', correct: true},
      {option:'Standard Virtualization File format \(SVFF\)', correct: false}
    ]
  },
  {
    question:'When creating replicas of existing virtual machines\, which of the following serves as a non\-runnable mold of the base virtual machine\?',
    answer:[
      {option:'Clone', correct: false},
      {option:'Snapshot', correct: false},
      {option:'Template', correct: true},
      {option:'Appliance', correct: false}
    ]
  },
  {
    question:'You have observed that your computer\’s performance has been steadily declining as the number of virtual machines hosted on that computer increases\. Which basic utility would you use to improve performance\?',
    answer:[
      {option:'Formatting the hard disk', correct: false},
      {option:'Fragmenting the hard disk', correct: false},
      {option:'Defragmenting the hard disk', correct: true},
      {option:'Spinning the hard disk', correct: false}
    ]
  },
  {
    question:'One of the Virtual Machines on your system will temporarily not be in use for some time soon\. As such\, you decide to keep the Virtual Machine’s files intact on the host computer\. Select the best action necessary to achieve this\.',
    answer:[
      {option:'Remove', correct: true},
      {option:'Delete', correct: false},
      {option:'Stop', correct: false},
      {option:'Pause', correct: false}
    ]
  },
  {
    question:'Identify the tool that Guest Additions provides to enable quick transfer of data between host and guest machines through a temporary storage facility\.',
    answer:[
      {option:'Shared folders', correct: false},
      {option:'Shared clipboard', correct: true},
      {option:'Synchronization', correct: false},
      {option:'Generic host\/guest communications', correct: false}
    ]
  },
  {
    question:'You are about to make large\-scale changes to an existing Virtual Machine’s configuration\. To do this safely\, you decide to preserve the machine\’s state at different stages of the operation\. Which one of the following tools would you use to preserve the states\?',
    answer:[
      {option:'Snapshot', correct: true},
      {option:'Clone', correct: false},
      {option:'Clipboard', correct: false},
      {option:'Template', correct: false}
    ]
  },
  {
    question:'As you try to copy files from the host to the guest machine\, you observe that \“drag and drop\” is not working\. What would you check first\?',
    answer:[
      {option:'Is drag and drop installed\?', correct: false},
      {option:'Are the files copy-protected\?', correct: false},
      {option:'Is drag and drop enabled\?', correct: true},
      {option:'Is the right-click button functioning\?', correct: false}
    ]
  },
  {
    question:'You are modifying a fixed\-size virtual hard disk image\. The requirements state that the image file must be simultaneously available to many Virtual machines and the state of the image should not be included in snapshots\. Select the mode that you would use when modifying the image\.',
    answer:[
      {option:'Normal', correct: false},
      {option:'Shareable', correct: true},
      {option:'Immutable', correct: false},
      {option:'Write\-through', correct: false}
    ]
  },
  {
    question:'Which of the following power options is preferred to power off a Virtual Machine because it works through the guest operating system\’s shutdown routine\?',
    answer:[
      {option:'Shut down guest', correct: true},
      {option:'Suspend guest', correct: false},
      {option:'Power off', correct: false},
      {option:'Close guest', correct: false}
    ]
  },
  {
    question:'From the following set of VMWare workstation virtual switches\, identify one that lacks a bridge to the host computer\’s Network Interface Card \(NIC\)\.',
    answer:[
      {option:'VMnet0', correct: false},
      {option:'VMnet1', correct: true},
      {option:'VMnetl', correct: false},
      {option:'VMnet8', correct: false}
    ]
  },
  {
    question:'In a virtual machine\, how can you access a shared folder\?',
    answer:[
      {option:'As an appliance', correct: false},
      {option:'As an application', correct: false},
      {option:'As a network share', correct: true},
      {option:'As a drive share', correct: false}
    ]
  },
  {
    question:'Identify the VMWare Workstation options that allow you to run virtual machine guest applications from the host operating system\.',
    answer:[
      {option:'Unity Ware', correct: false},
      {option:'Unity View', correct: true},
      {option:'Unity Appliance', correct: false},
      {option:'Unity Application', correct: false}
    ]
  },
  {
    question:'You have been asked to provide printing services on VMWare Workstation Pro virtual machines\. What feature do you require in order to allow the Virtual machines to user\’s printers that are installed on the host computer\?',
    answer:[
      {option:'VMWare Workstation Pro Tools', correct: true},
      {option:'VMWare Workstation Pro Toolkit', correct: false},
      {option:'VMWare Workstation Pro Config', correct: false},
      {option:'VMWare Workstation Pro Setup', correct: false}
    ]
  },
  {
    question:'Which of the following is the most important characteristic distinguishing workstation and data center virtualization\?',
    answer:[
      {option:'Data replication', correct: false},
      {option:'Scalability', correct: true},
      {option:'Databasees', correct: false},
      {option:'Data migration', correct: false}
    ]
  },
  {
    question:'Isolate one characteristic that enables a guest operating system to communicate directly with the hypervisor\.',
    answer:[
      {option:'Lightened Input \/ Output \(I\/O\)', correct: false},
      {option:'Thin client', correct: false},
      {option:'Enlightened Input\/ Output \(I\/O\)', correct: true},
      {option:'Thick client', correct: false}
    ]
  },
  {
    question:'What unit of storage can you use to restore a backup onto another computer with the most ease\?',
    answer:[
      {option:'Drive', correct: false},
      {option:'Folder', correct: false},
      {option:'Disk', correct: false},
      {option:'File', correct: true}
    ]
  },
  {
    question:'Which one of the following software techniques does VMWare use to free unused memory in a Virtual machine using a component of VMWare tools\?',
    answer:[
      {option:'Ballooning', correct: true},
      {option:'Non\-Uniform Memory Management \(NUMA\)', correct: false},
      {option:'Memory provisioning', correct: false},
      {option:'Second Level Address Translation \(SLAT\)', correct: false}
    ]
  },
  {
    question:'Before bringing down a machine for maintenance\, you always ensure the presence of an alternative\. What term best describes this practice\?',
    answer:[
      {option:'Fault tolerance', correct: false},
      {option:'High availability', correct: true},
      {option:'Hyper\-convergence', correct: false},
      {option:'Load balancing', correct: false}
    ]
  },
  {
    question:'Imagine that you have selected an 8GB dynamic virtual disk\. If the virtual disk is 2GB large\, how much space will the virtual disk file occupy on the host computer\’s hard drive\?',
    answer:[
      {option:'2 GB', correct: true},
      {option:'0 GB', correct: false},
      {option:'6 GB', correct: false},
      {option:'8 GB', correct: false}
    ]
  }
 ]
  constructor() { }

  getQuizzes(){
    return this.quizzes;
  }
}
